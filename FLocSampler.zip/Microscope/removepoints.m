function [ struct_folder ] = removepoints( struct_folder )
% REMOVE THE VIRTUAL FOLDERS NAMED BY "." OR ".." CREATED BY AN ASSIGNATION
% OF THE TYPE ==> struct_folder=dir
flag1=(strcmp({struct_folder.name}, '.')==1|strcmp({struct_folder.name}, '..')==1 );
struct_folder(flag1)=[];
isdirectory=~cell2mat({struct_folder.isdir});
struct_folder(isdirectory)=[];

end

