function [ isbacteria] = generate_lists_bacteria_v2( npart,dbac,PGRID,XX,nx,ny,nz,LI,sq,rbac )
%%% generate_lists_bacteria_v2 %%%
% Generate a lists with the boolean positions matching to which points in the grid are inside a cell    
%
%
% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

isbacteria=boolean(zeros(nx*ny*nz,1));

% Select closest points to bacterial aggregate
for i=1:npart
    % Make a first filtration of those points which are contained in a ball with diameter equal to the length of the bacteria
    choseni=sum(bsxfun(@minus,PGRID,XX(i,1:3)).^2,2)-(1.05*dbac)^2<=0 & ~isbacteria;
    
    candidates=gather(find(choseni==1));
    selected=boolean(zeros(size(candidates,1),1));
    
    pointA=XX(i,1:3)-LI(i,1:3)*0.5*sq; % Calculate furthest points of spherocylinder squeleton  (-X----X-)
    pointB=XX(i,1:3)+LI(i,1:3)*0.5*sq;
    
    APs=bsxfun(@minus,PGRID(choseni,:),pointA);  % Calculate vector between all grid points and pointA, pointB
    BPs=bsxfun(@minus,PGRID(choseni,:),pointB);
    aalpha=sum(bsxfun(@times,APs,LI(i,1:3)),2);  % Calculate vector projection length of AP vectors over li through dot product
    
    dd=sqrt(sum((APs-bsxfun(@times,aalpha,LI(i,1:3))).^2,2));  % calculate distance between AP vectors and li (distance ortogonal to bacterial surface)
    dd(aalpha<0)=sqrt(sum(APs(aalpha<0,:).^2,2));    % puesto que point A es XX-li, todas las calculadas a partir del producto escalar de
    dd(aalpha>sq)=sqrt(sum(BPs(aalpha>sq,:).^2,2));  % AP y LI estar�n referidas a la posici�n de pointA : Values greater than 0, projection is in B point direction. Values smaller than 0, 
    chosencenter=dd<=0.99*rbac;                       % the opposite direction is chosen (out of squeleton) 
    selected(gather(chosencenter))=1;                  % Those points belonging to the bacteria shall be those with a distance smaller than 1 radius
    
    newbacells=candidates(selected);
    isbacteria(newbacells)=1;  
end

wait(gpuDevice)
pause(1)

end

