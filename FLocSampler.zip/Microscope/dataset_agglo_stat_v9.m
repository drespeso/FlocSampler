function [theor_aggregates,contacts,connectdist,CSD,CCD,agglo_color_data,agglo_color_tab] = dataset_agglo_stat_v9( data_set,T,nbac,dimcolor )
%%% dataset_agglo_stat_v9 %%%
%  Compute geoemetric and composition parameters. Composition parameters are referred to   
%  aggregates formed with two strains / fluorescent strains, termed as green (G) and red (R) (colors). 


% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  Variable allocation         
nagglos=sum(T(:,2)~=0);                    % Number of aggregates to analyze
CCD=zeros(dimcolor,nbac);               % Allocate 

agglo_color_data=zeros(nagglos,12);  % Allocate color composition matrix

CSD=zeros(1,nbac);                           % Cluster Size Distribution array
EVD=cell(1,1);                                     % Evolvent diameter 
NP=cell(1,1);                                        % Number of cells within the aggregate
RG=cell(1,1);                                       % Radius of Gyration
treeness=cell(1,1);                              % Coordination index 
eccentricity=cell(1,1);                          % Eccentricity index
bondsvolume=cell(1,1);                      % Bonds per volume

newNP=zeros(1,nagglos);                  % Auxiliary arrays
newRG=zeros(1,nagglos);
newEVD=zeros(1,nagglos);
agglotreeness=zeros(1,nagglos);
% clustercoloratios=zeros(3,nagglos);
aggloeccen=zeros(1,nagglos);
bondspervolume=zeros(1,nagglos);

ppcont=0;                                          % pole-pole bonds 
pbcont=0;                                          % pole-body bonds
bbcont=0;                                          % body-body bond
pospoles=0.9;                                   % Position from which I consider a contact is pole and which is body. For example pospole = 0.9 means
                                                           % that the body of a cell is considered the volume of the sperocylinder within the range [-0.9,0.9] of 
                                                           % the parametrized cell length within the range [-1,1]                
contacts=[];                                            

for j=1:nagglos                                   % For every aggregate 
    a=table2array(data_set(data_set.Tag==T(j,1),1:11));     % Gather cell data of the aggregate j
    
    dbac=(a(:,9));
    npart=size(a,1);
    
    agglo_color_data(j,1)=npart;
    
    X=[a(:,1:3) zeros(npart,1) a(:,8)];
    li=a(:,4:7);             % contains the data of the normalized axis
    li(:,4)=(2*li(:,4)-dbac);  % position 4 must contain the squeleton length la posicion 4, so we need to compute it
    ccc=a(:,8);              % contains the colors of all selected cells

    
    % CALCULATE RADIUS OF GYRATION AND CSD

    I=mean(X(:,1:3),1);                                          % Mass center of aggregate
    dist=sum(bsxfun(@minus,X(:,1:3),I).^2,2);    % mass center - cell  squared distance  
    
    newNP(1,j)=npart;
    
    if npart == 1
        newRG(1,j)=0;
    else
        newRG(1,j)=sqrt(1/npart*sum(dist));            
    end
    CSD(1,npart)=CSD(1,npart)+1;                         
    
    % CALCULATE TREENESS AND ECCENCRICITY INDEXES FOR AGGREGATES
    
    if npart>1
        dist=zeros(npart,npart);
        for i=1:npart-1
            dist(i,i+1:npart)=sum(bsxfun(@minus,X(i+1:npart,1:3),X(i,1:3)).^2,2);
        end
        newEVD(1,j)=max(max(dist));
        criticlength=max(li(:,4))+mean(dbac);  % We use as critic distance to discriminate neighbors with potential bonds among cells the maximum cell length present among all cells forming the aggregate
        
        connect=dist<=criticlength^2&dist~=0;       % Connectivity matrix of neighbors 
        [elem1,elem2]=ind2sub(size(connect),find(connect==1));
        E=[elem1 elem2];
        [ SSTAR,TSTAR,y1,y2] = buildcontactvectors4(X,li,E);   % Compute the distance among pairs of neighbors to check if they are in contact
        notconnected=sqrt(sum((y1-y2).^2,2))>1.25*mean(dbac); % Use the previous calculation (more accurate) to refine the connectivity matrix result
        SSTAR(notconnected)=[];
        TSTAR(notconnected)=[];
        
        elem1(notconnected)=[];
        elem2(notconnected)=[];
        connect(E(notconnected,1),E(notconnected,2))=0;  % Update connect matrix
%         E(notconnected,:)=[];  % matriz donde tengo las conectividades de c�lulas por �ndice segu�n lo ocupan el la matriz de coordenadas X 
        totbond=numel(elem1);                                               % Total bonds
        if totbond ~= 0                                                               % Count how many connectivities are pole - pole,  pole - body or body - body 
            contacts=[contacts; [SSTAR TSTAR]];
            ppcont= ppcont+ sum(abs(SSTAR)>=pospoles & abs(TSTAR)>=pospoles);   % contamos el numero de conexiones en el agregado que son polo - polo, polo-cuerpo o cuerpo - cuerpo
            pbcont= pbcont+ sum((abs(SSTAR)>=pospoles & abs(TSTAR)<pospoles) | (abs(SSTAR)<pospoles & abs(TSTAR)>=pospoles));
            bbcont= bbcont+sum(abs(SSTAR)<pospoles & abs(TSTAR)<pospoles);

            gbonds=sum(ccc(elem1)==1 & ccc(elem2)==1);                  % Count the number of bonds per color: G-G, G-R or R-R
            if dimcolor==2
                grbonds=sum((ccc(elem1)==1 & ccc(elem2)==2) | (ccc(elem1)==2 & ccc(elem2)==1));
                rbonds=sum(ccc(elem1)==2 & ccc(elem2)==2);
            end

            CCD(1,npart)=CCD(1,npart)+sum(ccc==1);  %%?????????????????????????????????????
            CCD(2,npart)=CCD(2,npart)+sum(ccc==2);

            %%% Store number of cells of each color (G R)        
            agglo_color_data(j,2)=sum(ccc==1);      % Green cells (G)
            if dimcolor==2
                agglo_color_data(j,3)=sum(ccc==2);  % Red cells  (R)
            end 
            
            %%% Total Bond percentages G-G, G-R y R-R
            agglo_color_data(j,4)=gbonds/totbond;      % G-G 
            if dimcolor==2
                agglo_color_data(j,5)=grbonds/totbond; %G-R
                agglo_color_data(j,6)=rbonds/totbond;   % R-R
            end

            %%% Average distance between cells forming bonds of each color  type (G-G, G-R and R-R) 
            distances=sqrt(dist);
            [I,J]=find(distances~=0);
            P=[ccc(I) ccc(J) distances(distances~=0)];  % Rows : Bonds , Columns : 1-2 : color of each bacteria , 3: distances among cell centers 
            
            agglo_color_data(j,7)=mean(P(P(:,1)==1 & P(:,2)==1,3)); % Avg. distance among cells connections of type G-G
            if dimcolor==2
               agglo_color_data(j,8)=mean(P((P(:,1)==1 & P(:,2)==2) | (P(:,1)==2 & P(:,2)==1),3)); % Avg. distance among cells connections of type R-G
               agglo_color_data(j,9)=mean(P(P(:,1)==2 & P(:,2)==2,3)); % Avg. distance among cells connections of type R-R
            end
            agglo_color_data(j,10)=mean(P(:,3)); % Avg. distance among all connected cells
            
            if isnan(agglo_color_data(j,7))  %% Remove NaN (if any)
                agglo_color_data(j,7)=0;
            end
            if isnan(agglo_color_data(j,8))
                agglo_color_data(j,8)=0;
            end
            if isnan(agglo_color_data(j,9))
                agglo_color_data(j,9)=0;
            end
            
            % Shannon Entropy calculation for color ratio composition
            pg= agglo_color_data(j,2)/agglo_color_data(j,1);   
            pr= 1-pg;
            if pg == 0 || pg == 1
                agglo_color_data(j,11)=0;
            else
                agglo_color_data(j,11)= -pg*log2(pg)-pr*log2(pr);
            end
            
            % Shannon Entropy calculation for bonding type probability
            pg= agglo_color_data(j,4);
            pgr= agglo_color_data(j,5);
            pr= agglo_color_data(j,6);
            if pg == 1 || pr == 1 || pgr == 1 
                agglo_color_data(j,12)=0;
            else
                if pg == 0
                    agglo_color_data(j,12)= -pgr*log2(pgr)-pr*log2(pr);
                elseif pgr == 0
                    agglo_color_data(j,12)= -pg*log2(pg)-pr*log2(pr);
                elseif pr == 0 
                    agglo_color_data(j,12)= -pg*log2(pg)-pgr*log2(pgr);
                else
                    agglo_color_data(j,12)= -pg*log2(pg)-pgr*log2(pgr)-pr*log2(pr);
                end
            end            
            it = (sum(connect,2));                                         %Coordination index for each cell within the aggregate
            agglotreeness(1,j)=sum(it,1)/size(it,1);       

            ie = zeros(npart,1);                                             % Eccentricity index calculation
            for kkk = 1:npart
                subcluster = find(connect(kkk,:)==1);
                if isempty(subcluster)
                    ie(kkk) = 0;
                else
                    coordCM = X(kkk,1:3);
                    for jjj = 1:size(subcluster,2)
                        coordCM = coordCM+X(subcluster(jjj),1:3);
                    end
                    CMcluster = coordCM/(size(subcluster,2)+1);  % cluster centroid
                    normamax=0;
                    for jjj = 1:size(subcluster,2)
                        norma = norm(CMcluster-X(subcluster(jjj),1:3));
                        if norma > normamax
                            normamax = norma;
                        end
                    end
                    if norm(CMcluster-X(kkk,1:3))>normamax  
                        normamax = norma;
                    end
                    ie(kkk) = norm(CMcluster-X(kkk,1:3))/normamax;
                end
            end
            aggloeccen(1,j)=sum(ie,1)/size(ie,1);
            bondspervolume(1,j)=totbond/sum(a(:,9));            % Number of bonds per volume
        end
    else
        agglotreeness(1,j)=0;
        aggloeccen(1,j)=0;
        bondspervolume(1,j)=0;
    end

end 

% Export variables
connectdist=[ppcont pbcont bbcont];    % array to export with cell-cell contact type
NP{1,1}=horzcat(NP{1,1},newNP);
RG{1,1}=horzcat(RG{1,1},newRG);
EVD{1,1}=horzcat(EVD{1,1},newEVD);
treeness{1,1}=horzcat(treeness{1,1},agglotreeness);                        
eccentricity{1,1}= horzcat(eccentricity{1,1},aggloeccen);
bondsvolume{1,1}= horzcat(bondsvolume{1,1},bondspervolume);

EEVD=EVD{1,1};
RRGG=RG{1,1};
NNPP=NP{1,1};
TREE=treeness{1,1};
ECCEN=eccentricity{1,1};
BONDSVOL=bondsvolume{1,1};

mask=RRGG==0;     % If any calculation error, discard the sample
EEVD(mask)=[];
RRGG(mask)=[];
NNPP(mask)=[];
TREE(mask)=[];
ECCEN(mask)=[];
BONDSVOL(mask)=[];

clear mask

theor_aggregates=table(EEVD',RRGG',NNPP',TREE',ECCEN',BONDSVOL','VariableNames',{'EVD','RG','NP','TREE','ECCEN','BONDSVOL'});
agglo_color_tab=table(agglo_color_data(:,1),agglo_color_data(:,2),agglo_color_data(:,3),agglo_color_data(:,4),agglo_color_data(:,5),agglo_color_data(:,6),agglo_color_data(:,7),agglo_color_data(:,8),agglo_color_data(:,9),agglo_color_data(:,10),agglo_color_data(:,11),agglo_color_data(:,12),'VariableNames',{'NP','NCELLG','NCELLR','GGBONDPROB','GRBONDPROB','RRBONDPROB','DISTGG','DISTGR','DISTRR','DISTALL','ENTROPY_COLOR','ENTROPY_BOND'});

end

