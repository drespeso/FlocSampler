function [ PGRID,nx,ny,nz,XX ] = generategrid_v4(max_cubelengthxyz,center_image, X, nx)
%%% generategrid_v4 %%% 
% Create a meshgrid to cover the whole domain where the aggregate is place for evaluation 
%
% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

center_mass=mean(X,1);     % Mass center of particles
shift_vec=center_image-center_mass;  % Shift mass center of cube and cells to  [1000,1000,1000])
X=X+shift_vec;                      % Traslado todas las bacterias del agregado para ubicar su centro de masas en [1000,1000,1000]
XX=gpuArray(X);                    % Use gpuArray acceleration module to boost computations. It is not necessary      

centerx=0.5*(max(X(:,1))+min(X(:,1)));  % Locate geometric center of aggregate
centery=0.5*(max(X(:,2))+min(X(:,2)));
centerz=0.5*(max(X(:,3))+min(X(:,3)));

% Compute boundaries of box domain using geometric center of aggregate as reference, and the largest length of all aggregates      
xcube(1)=centerx-0.5*max_cubelengthxyz(1);
xcube(2)=centerx+0.5*max_cubelengthxyz(1);
xcube(3)=centery-0.5*max_cubelengthxyz(2);
xcube(4)=centery+0.5*max_cubelengthxyz(2);
xcube(5)=centerz-0.5*max_cubelengthxyz(3);
xcube(6)=centerz+0.5*max_cubelengthxyz(3);

% CREATE GRID POINT COORDINATES FOR FUNCTION EVALUATION

Dspace=1/nx*(xcube(2)-xcube(1));

while Dspace >= 0.1
     nx=nx+5;
     Dspace=1/nx*(xcube(2)-xcube(1));
end
ny=nx;
nz=nx;

[x,y,z] = meshgrid(linspace(xcube(1),xcube(2),nx),linspace(xcube(3),xcube(4),ny),linspace(xcube(5),xcube(6),nz));  % Create meshgrid matrices

Pgrid(:,1)=reshape(x,nx*ny*nz,1);
Pgrid(:,2)=reshape(y,nx*ny*nz,1);
Pgrid(:,3)=reshape(z,nx*ny*nz,1);

PGRID=gpuArray(Pgrid);    % Store meshgrid lists  into a gpu accelerated array (optional)

end

