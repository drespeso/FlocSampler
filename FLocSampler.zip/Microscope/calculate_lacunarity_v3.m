function [ lacunarity_r ] = calculate_lacunarity_v3( max_cubelengthxyz, center_image, data_set_raw,T,step,nx,lbac,dbac,rpoints  )
%%%% calculate_lacunarity_v3  %%%%
%  This is a three-dimensional generalization of the "gliding box" algorithm proposed by C. Allain and M. Cloitre [1] 
% The algorithm encases the aggregate into a main cubic box, and discretize the space into a grid of smaller cubic boxes
% A virtual evaluation box is sequentially moved through the discretized cubic domain by advancing leaps of known size, 
% and evaluate whether the box is within the aggregate domain or empty. Results are stored in a frequency distribution matrix which
% register this process for different evaluation box sizes. A probability distribution is obtained by dividing by the total number of boxes, 
% and the first and second moments of the distribution are derived and used to estimate lacunarity

% Reference
% [1] "C. Allain and M. Cloitre, Phys. Rev. A 44, 3552 (1991)"


% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


rbac=0.5*dbac;            % Radius of the cell
sq=lbac-dbac;              % Squeleton of the cell
lacunarity_r=zeros(size(T,1),numel(rpoints)); % % matriz que incluye: filas: agregados medidos, columnas: Valor lacunaricidad para el rango de cajas r que uso

for i=1:size(T,1)
    X=data_set_raw{data_set_raw.Tag==T(i,1),1:3};
    LI=data_set_raw{data_set_raw.Tag==T(i,1),4:6};
    npart=T(i,2);
    
    % Create a meshgrid to cover the whole domain where the aggregate is place for evaluation 
    [ PGRID,nx,ny,nz,XX ] = generategrid_v4(max_cubelengthxyz,center_image, X, nx);  
   
    % create boolean linear lists containing which points in the cube covering the image virtualized aggregate has bacteria 
    [ isbacteria] = generate_lists_bacteria_v2( npart,dbac,PGRID,XX,nx,ny,nz,LI,sq,rbac );

    % Create lacunarity measurements
    snap_size=nx;
    for k=1:numel(rpoints)
        r=rpoints(k);
        [lacun_r] = boxcount_v6(isbacteria,snap_size,r,step);
        lacunarity_r(i,k)=lacun_r;
    end
%     display(i/size(T,1)*100)

end

