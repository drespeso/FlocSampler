function [ data_set ] = clusters4( data_set)
%%% BARRE EL DATA SET DE CELULAS PARA ASIGNAR ETIQUETAS QUE LOS AGRUPE POR
%%% AGREGADOS SEGUN SU PROXIMIDAD.
% ENTRADA: DATA_SET CON TAG CLASIFICADO POR FOTO
% SALIDA: DATA_SET CON TAG CLASIFICADO POR AGREGADO

% data_set=sortrows(data_set,11);  %%% ORDENAR DATA SET POR NUMERO DE FOTO
% maxphotos=max([data_set.Tag]);
photolistag=unique([data_set.Tag]);   %%% los tag en este punto corresponden al n�mero de foto del que proviene la particula en cuesti�n 
maxphotos=numel(photolistag);
% display(2*mean([data_set.Length]))
% display(2*max([data_set.Length]))
% pause
% criticlength=2*mean([data_set.Length]); % distancia critica para lo que considero que estan unidas
indexagglo=1;
picturetag=data_set.Tag;

for j=1:maxphotos
    chosen=find(picturetag==photolistag(j));
%     criticlength=max(table2array(data_set(chosen,7))); % distancia critica para lo que considero que estan unidas
    npart=size(chosen,1);
    dist=zeros(npart,npart);
    X=table2array(data_set(chosen,:));
%     X(:,4:6)=bsxfun(@times,X(:,4:6),0.5*X(:,7)-0.5*X(:,9));
    X(:,7)=(X(:,7)-X(:,9));  % longitud del esqueleto = longitud del eje principal del elipsoide - diametro bacteria
    criticlength=max(table2array(data_set(chosen,7))); % distancia critica para lo que considero que estan unidas (d="la m�xima longitud bacteria")
    
    for i=1:npart-1
        dist(i,i+1:npart)=sum(bsxfun(@minus,X(i+1:npart,1:3),X(i,1:3)).^2,2); % calculo el CUADRADO de la distancia
    end

    connect=dist<=criticlength^2&dist~=0;
    
    checked=boolean(ones(npart,1));
    listaparticles=1:npart;
    neighbors=zeros(1,npart);  % asignamos memoria al vector de vecinos
   
    while any(checked)                                         % para todos lso agregados de esa imagen
        indexpart=find(checked,1,'first');                     % buscar el primer elemento no nulo de la lista de chequeados
        neighbors(1,1)=indexpart;
        sizeneigh=1;  % escalar que mide el tama�o del vector "vecinos". Al principio se fija sobre 1 
        [ neighbors,sizeneigh,X,checked ] = findneigh3(neighbors,sizeneigh,indexpart,connect,listaparticles,checked,X,indexagglo);
        indexagglo=indexagglo+1;
    end
    data_set(chosen,11)=array2table(X(:,11));

end

data_set=sortrows(data_set,11);  % ordenar tags


end
