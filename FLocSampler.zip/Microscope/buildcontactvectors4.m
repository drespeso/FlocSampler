function [ SSTAR,TSTAR,y1,y2] = buildcontactvectors4(xni,li,E)
%
%%% Buildcontactvectors4 %%%
% This script implement the algorithm developed by Sevilla and Lago (1994) [1], which is gently described in Pournin et al. (2005) [2] 
% The algorithm computes the shortest distance between two spherocylinders in general position in a 3D space
%
% The input of the script is:
% - xni: spherocylinder positions (3D) 
% - li: pos (1:3) => Normalized vector describing the 3D orientation of the axis
%       pos (4)    => Length of the spherocylinder
% - E: linear index of both cells within the aggregate which are being analyze (e.g. E=[1 3]). They have to match with xni and li ordering        
% 
% NOTE: The script allows vectorial inputs: each case to compute will add an additional row to E, and will add an extra row to output arrays    
%
%
% The output of the script returns:
% - SSTAR, TSTAR: relative parametrized axis positions of both spherocylinders (within the range [-1,1]), whose absolute euclidean distance is minimal    
% - y1, y2: Coordinates of the closest points (located in the surface of each of the analyzed spherocylinders) (y1 and y2),     
%
% References
% [1] Sevilla, P. and Lago, S.  1985.  A fast algorithm to calculate shortest distances between linear segments and angular averages for soft repulsive potentials depending on shortest dista. Comp. Chem. 9(1), 39-42.
% [2] Pournin, L., Weber, M., Tsukahara, M., Ferrez, J.-A., Ramaioli, M., and Liebling, T. M. (2005) Three-dimensional distinct element simulation of spherocylinder crystallization. Granular Matter 7, 119� 126,  DOI: 10.1007/s10035-004-0188-4
%
%
% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

aux=size(E,1);
y1=zeros(aux,3);
y2=zeros(aux,3);
x11=xni(E(:,1),1:3);
x22=xni(E(:,2),1:3);
l1=0.5*li(E(:,1),4); 
l2=0.5*li(E(:,2),4);
SSTAR=zeros(aux,1);
TSTAR=zeros(aux,1);

a11=bsxfun(@times,l1,li(E(:,1),1:3));
a22=bsxfun(@times,l2,li(E(:,2),1:3));
norma11=sqrt(sum(a11.^2,2));
norma22=sqrt(sum(a22.^2,2));
gate=boolean(zeros(1,4));

paralellcond=cos(5/180*pi);
alignedcond=cos(5/180*pi);

notparallel=abs(dot(a11,a22,2)./(norma11.*norma22))<paralellcond;

parallel=~notparallel;

if any(notparallel) % checks if there is an nonzero element in notparallel
    gate(1)=1;
    a=dot(a11(notparallel,:),a11(notparallel,:),2);
    b=-dot(a11(notparallel,:),a22(notparallel,:),2);
    c=dot(a22(notparallel,:),a22(notparallel,:),2);
    d=dot(a11(notparallel,:),(x11(notparallel,:)-x22(notparallel,:)),2);
    e=-dot(a22(notparallel,:),(x11(notparallel,:)-x22(notparallel,:)),2);
    delta=a.*c-(b.*b);
    gamma1=(b.*d-a.*e)./delta;
    [tstar] = alphaf(gamma1);
    gamma2=(-b.*tstar-d)./a;
    [sstar]=alphaf(gamma2);
    
    newtstar=abs(gamma2) > 1;
    gamma3=(-b.*sstar-e)./c;
    alphaa=alphaf(gamma3);
    tstar(newtstar)=alphaa(newtstar);
    TSTAR(notparallel)=tstar;
    SSTAR(notparallel)=sstar;
end    

if any(parallel)
    gate(2)=1;
    a11parallel=a11(parallel,:);
    norma11parallel=sqrt(sum(a11parallel.^2,2));
    a22parallel=a22(parallel,:);
    x11parallel=x11(parallel,:);
    x22parallel=x22(parallel,:);
    y11parallel=zeros(size(x11parallel));
    y22parallel=zeros(size(x22parallel));
    
    r12=x22parallel-x11parallel;
    normr12=sqrt(sum(r12.^2,2));
    notaligned=abs(dot(a11parallel,r12,2)./(norma11parallel.*normr12))<alignedcond;  
    aligned=~notaligned;
    
    if any(notaligned)
        gate(3)=1;
        a11paranotal=a11parallel(notaligned,:);
        a22paranotal=a22parallel(notaligned,:);
        x11paranotal=x11parallel(notaligned,:);
        x22paranotal=x22parallel(notaligned,:);
        y22paranotal=zeros(size(x22paranotal));
        y11paranotal=zeros(size(x11paranotal));
        
        kappa=dot(x22paranotal-x11paranotal,a11paranotal,2)./sqrt(sum(a11paranotal.^2,2)); % Compute the vector joining the center of both spherocylinders. Project it over the axis of cylinder 1 (a11). Kappa compares the length of the projection with the a11 length (fold change)    
        kp=x11paranotal+kappa.*a11paranotal./sqrt(sum(a11paranotal.^2,2));              % Compute the dot where projection ends
        orto=x22paranotal-kp;                                                           % Compute orthogonal vector to both spherocylinders joining x22 with kp
        pproy=zeros(size(x22paranotal));
        pproy2=zeros(size(x22paranotal));    
        isright=kappa>0; % Distinguish two cases depending on whether x22-x11 and a11 vector senses matches or not
        isleft=~isright;
        samesign=sign(dot(a11paranotal,a22paranotal,2))==1;
        signos=zeros(size(x22paranotal,1));
        signot=zeros(size(x22paranotal,1));

        if any(isright)
            pproy(isright,:)= x11paranotal(isright,:)+a11paranotal(isright,:)+orto(isright,:);          %  Compute the projection of point x1+a11 (one extreme) in spherocylinder 2 
            pproy2(isright&samesign,:)= x22paranotal(isright&samesign,:)-a22paranotal(isright&samesign,:)-orto(isright&samesign,:);  % Compute the projection of opposite sideof pproy in spherocylinder 2  (depending on a22 sense, I should sum or substract)
            pproy2(isright&~samesign,:)= x22paranotal(isright&~samesign,:)+a22paranotal(isright&~samesign,:)-orto(isright&~samesign,:);
            
            y22paranotal(isright&samesign,:)= 0.5*(pproy(isright&samesign,:)+x22paranotal(isright&samesign,:)-a22paranotal(isright&samesign,:));   % Contact point of spherocylinder 2 is the average of pproy and the opposite side
            y22paranotal(isright&~samesign,:)= 0.5*(pproy(isright&~samesign,:)+x22paranotal(isright&~samesign,:)+a22paranotal(isright&~samesign,:));
            
            signot(isright)=sign(dot((y22paranotal(isright,:)-x22paranotal(isright,:)),a22paranotal(isright,:),2));                        % To assign a proper sign to t, compute y22-x22 and check the sign of its dot product with a22. If the result is >0, then they are aligned and is positive, otherwise negative
            ttstar(isright)=sqrt(sum((y22paranotal(isright,:)-x22paranotal(isright,:)).^2,2))./sqrt(sum(a22paranotal(isright,:).^2,2));     % To compute ttstar, calculate it as the norm of vector y22-x22 divided by the length of the semisqueleton (a22 norm)
            ttstar(abs(ttstar)>1)=sign(ttstar(abs(ttstar)>1));
            
            y11paranotal(isright&samesign,:)= 0.5*(pproy2(isright&samesign,:)+x11paranotal(isright&samesign,:)+a11paranotal(isright&samesign,:));      % Point  y11 is computed as the average of de pproy2 and the opposite side to the where pproy2 falls
            y11paranotal(isright&~samesign,:)= 0.5*(pproy2(isright&~samesign,:)+x11paranotal(isright&~samesign,:)+a11paranotal(isright&~samesign,:));

            signos(isright)=sign(dot((y11paranotal(isright,:)-x11paranotal(isright,:)),a11paranotal(isright,:),2));         % The same sign as above
            ssstar(isright)=sqrt(sum((y11paranotal(isright,:)-x11paranotal(isright,:)).^2,2))./sqrt(sum(a11paranotal(isright,:).^2,2));   % ssstar is computed as performed above
            ssstar(abs(ssstar)>1)=sign(ssstar(abs(ssstar)>1));
        end
        if any(isleft)
            pproy(isleft,:)= x11paranotal(isleft,:)-a11paranotal(isleft,:)+orto(isleft,:);
            pproy2(isleft&samesign,:)= x22paranotal(isleft&samesign,:)+a22paranotal(isleft&samesign,:)-orto(isleft&samesign,:);    % In case x22-x11 y a11 are not aligned
            pproy2(isleft&~samesign,:)= x22paranotal(isleft&~samesign,:)-a22paranotal(isleft&~samesign,:)-orto(isleft&~samesign,:);
            
            y22paranotal(isleft&samesign,:)= 0.5*(pproy(isleft&samesign,:)+x22paranotal(isleft&samesign,:)+a22paranotal(isleft&samesign,:));
            y22paranotal(isleft&~samesign,:)= 0.5*(pproy(isleft&~samesign,:)+x22paranotal(isleft&~samesign,:)-a22paranotal(isleft&~samesign,:));
            
            signot(isleft)=sign(dot((y22paranotal(isleft,:)-x22paranotal(isleft,:)),a22paranotal(isleft,:),2));
            ttstar(isleft)=sqrt(sum((y22paranotal(isleft,:)-x22paranotal(isleft,:)).^2,2))./sqrt(sum(a22paranotal(isleft,:).^2,2));
            ttstar(abs(ttstar)>1)=sign(ttstar(abs(ttstar)>1)); 
            
            y11paranotal(isleft&samesign,:)= 0.5*(pproy2(isleft&samesign,:)+x11paranotal(isleft&samesign,:)-a11paranotal(isleft&samesign,:));
            y11paranotal(isleft&~samesign,:)= 0.5*(pproy2(isleft&~samesign,:)+x11paranotal(isleft&~samesign,:)-a11paranotal(isleft&~samesign,:));
            
            signos(isleft)=sign(dot((y11paranotal(isleft,:)-x11paranotal(isleft,:)),a11paranotal(isleft,:),2));
            ssstar(isleft)=sqrt(sum((y11paranotal(isleft,:)-x11paranotal(isleft,:)).^2,2))./sqrt(sum(a11paranotal(isleft,:).^2,2));
            ssstar(abs(ssstar)>1)=sign(ssstar(abs(ssstar)>1));
        end
             
        ttstar(signot==-1)=-ttstar(signot==-1);
        ssstar(signos==-1)=-ssstar(signos==-1);

        NOTA=find(parallel==1);
        TSTAR(NOTA(notaligned))=ttstar;
        SSTAR(NOTA(notaligned))=ssstar;
    end
    if any(aligned)
        gate(4)=1;
        isright=sum(((x22parallel(aligned,:)-a22parallel(aligned,:))-(x11parallel(aligned,:)+a11parallel(aligned,:))).^2,2)< sum(r12(aligned,:).^2,2);
        isleft=~isright;
        
        a11paraal=a11parallel(aligned,:);
        a22paraal=a22parallel(aligned,:);
        x11paraal=x11parallel(aligned,:);
        x22paraal=x22parallel(aligned,:);
        y11paraal=zeros(size(x11paraal));
        y22paraal=zeros(size(x22paraal));
        
        y11paraal(isright,:)=x11paraal(isright,:)+a11paraal(isright,:);
        y22paraal(isright,:)=x22paraal(isright,:)-a22paraal(isright,:);
        y11paraal(isleft,:)=x11paraal(isleft,:)-a11paraal(isleft,:);
        y22paraal(isleft,:)=x22paraal(isleft,:)+a22paraal(isleft,:);
        
        totalalign=parallel;
        fparall=find(parallel==1); %  Store lists of parallel positions  in global array 
        fparnotalign=fparall(~aligned); % Parallel and not aligned positions in global array
        totalalign(fparnotalign)=0;
        
        paralign=parallel==1 & totalalign==1;
        aaux=zeros(aux,3);
        aaux(paralign)=isright;
        SSTAR(paralign==1 & aaux)=1;
        TSTAR(paralign==1 & aaux)=-1;
        aaux(paralign)=isleft;
        SSTAR(paralign==1 & aaux)=-1;
        TSTAR(paralign==1 & aaux)=1;        
    end
end

if gate(1) == 1 && gate(2) == 0 % all bars are in general position
    y1=x11+bsxfun(@times,sstar,a11);
    y2=x22+bsxfun(@times,tstar,a22);
else  % some bars are in parallel position
    if gate(4)== 1 && gate(3)== 1  % parallel bars are some aligned and other disaligned
        y11parallel(aligned,:)=y11paraal;
        y22parallel(aligned,:)=y22paraal;
        y11parallel(notaligned,:)=y11paranotal;
        y22parallel(notaligned,:)=y22paranotal;
    elseif gate(4)== 1 && gate(3)== 0  % all parallel bars are in disaligned position
        y11parallel=y11paraal;
        y22parallel=y22paraal;
    elseif gate(4)== 0 && gate(3)== 1 % all parallel bars are in aligned position
        y11parallel=y11paranotal;
        y22parallel=y22paranotal;
    end
    
    if gate(1) == 0 && gate(2) == 1 % all bars are parallel
        y1=y11parallel;
        y2=y22parallel;
    elseif gate(1) == 1 && gate(2) == 1 % some bars are parallel and others not
        y1(notparallel,:)=x11(notparallel,:)+bsxfun(@times,sstar,a11(notparallel,:));
        y2(notparallel,:)=x22(notparallel,:)+bsxfun(@times,tstar,a22(notparallel,:));        
        y1(parallel,:)=y11parallel;
        y2(parallel,:)=y22parallel;
    end
end



