function [lacunarity] = boxcount_v6(isbacteria,snap_size,r,step)
%%% boxcount_v6 %%%
% It moves through the 3D cubic domain of size snap_size with an evaluator box of side r    
% snap_size - Side of the cubic domain to cover. Must dimensionally fit (in matrix size terms) with isbacteria, that is, isbacteria = snap_size^3 
% step - Number of units of advance per leap of avaluation box in any direction
% isbacteria - 1D boolean array, where 1 indicates the presence of bacteria. 

% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%

c=reshape(isbacteria,snap_size,snap_size,snap_size); % Reshape isbacteria as a three-dimensional matrix
nsteps=ceil((snap_size-r-1)/step); %% Number of steps to move in one direction to cover the whole domain

massbox=zeros(r^3,2);   % Frequency vector of masses found when covering the whole domain    
massbox(:,1)=1:r^3;        % Column 1: Mass values. It is valued between 0 and r^3  
                                         % Column 2: Number of boxes with each mass   

%%% The loop always start in matrix postion [1,1,1] 
    
for i=0:nsteps
    for j=0:nsteps
        for k=0:nsteps
            chosen=c(1+i*step:i*step+r,1+j*step:j*step+r,1+k*step:k*step+r);
            if any(chosen(:))
               massbox(sum(chosen(:)),2)=massbox(sum(chosen(:)),2)+1;
            end
        end
    end
end

total_boxes_r=numel(0:nsteps)^3;
probab_dist_mass=massbox;
probab_dist_mass(:,2)=massbox(:,2)/total_boxes_r;   % Compute probability distribution

Z1=sum(probab_dist_mass(:,1).*probab_dist_mass(:,2));    % Compute first and second moments of probability distribution
Z2=sum((probab_dist_mass(:,1).^2).*probab_dist_mass(:,2));
lacunarity = Z2/Z1^2;                                                           % Obtain lacunarity

end