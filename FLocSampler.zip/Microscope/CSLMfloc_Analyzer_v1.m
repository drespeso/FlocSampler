
% CSLMfloc_Analyzer_v1- Confocal Scanning Laser Microscopy (CSLM) analysing script to characterize microbial floc variability                   
%  
%  GENERAL DESCRIPTION
%  --------------------
%  This script process images obtained by using Confocal Scanning Laser Microscopy (CSLM) gathered from an aggregated sample.
%  stored as *.CSV files. The script measure the dispersion of the obtained data points and compute a set of metrics that 
%  characterize the morphological variability of the flocs present in the sample. This quantification is given as a set of normalized scores
%  for each target metric that are plot together into a radar chart, obtaining a multidimensional profile where samples can be compared graphically 
%  
%
%  INPUT:
%
%  *.CSV files containing parametrized positions and orientation of cells detected using CSLM imaging                                                    
%       
%  OUTPUT
% 
%  A table containing a set of metrics quantifying the aggregate variability 
%
%


%  DATA PROCESSING DESCRIPTION AND WARNINGS
%  ---------------------
% Z-stack images (in *.lif or any other formta) have to be previously treated with IMARIS software (or any other)          
% The scope of this pre-treatment is to parametrize the position of detected cell in every image, and store spatial data as *.csv files
% Thresholding and parametrization have to be performed using an "ellipsoid body detector algorithm", that is, image processing software
% should allow look and recognize ellipsoidal / cylindrical bodies within Z-stack images. The required parameters to allow the virtualization of Z-stack cells are the following:
% 
% 1- Position: Contains the X,Y and Z coordinates of the detected cells
% 2- Main Axis orientation: Should contain the direction of the main axis in every detected ellipsoid /cylinder (given as normalized 3D vector) 
% 3- Main Axis length: Should contain the length of the detected body considering its main axis
% 4 - Radial axis length: Should contain the length of the ellipsoid / cylinder in any of the radial directions
% 5 - Volume: Should contain the volume occupied by the detected body

% The above described data is expected to be stored as separated *.csv files using a folders hierarchy structured following this way:                 
% Strain / Sample name ==> Fluorescent channel (1 folder per channel) == > ID_image (1 image per image)   

% From this folder tree, it is derived that every sample will contain as folders as inspected fluorescent channels, and within this folder     
% there will be a folder for every analyzed image. Thus cells detected in the same image, but in different fluorescent channels are stored in different folders            

% Every image folder has to contain a *csv very file containing the data of the previously parameters, strictly respecting the following order:
% 1- Main Axis orientation
% 2- Total Length of main axis
% 3- Total Length of radial axis A (picked by pretreatment software)
% 4- Total Length of radial axis B (picked by pretreatment software)
% 5- Spatial coordinates
% 6- Volume
     
% The program is designed to automatically navigate through this folder tree and recover the data into a table containing all detected cells in every image of the analyzed sample.   
%  After data of all cells is properly tabulated, cells belonging to each image are gathered and analyzed to determine how are they clustered, and relabel the cell ids with an aggregate tag.
% 
% Finally, metrics of interest are computed for every aggregate, stored and averaged     
%
%
%
% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear

dimcolor=2;   % Number of fluorescent channels used 
nbac=8000;   % Arbitrarily large number of bacteria that can be found within an aggregate (memeroy allocation purposes)
strain_name='371'; 
basepath='F:\Maletin de trabajo\Bacterial Origami\Coronavirus crisis work 12_05_20\Origami paper\code\Microscope';   % Locate where scripts are located

cd(basepath);                                 % Change to basepath
addpath(genpath(basepath))        % Add basepath in MATLAB environment

box=dir;                                           % Obtain a list of files within basepath

[ box ] = removepoints( box );       % dir command generate "dummy folders" with name '.' ==> This function removes them 
maxcolor=size(box,1);                   % The number of folders must be the same as the number of analyzed fluorescent channels 

data_set=table(0,0,0,0,0,0,0,0,0,0,0);                         % Create the data set table where the data of every cell will be stored
data_set.Properties.VariableNames = {'PosX' 'PosY' 'PosZ' 'AxisX' 'AxisY' 'AxisZ' 'Length' 'Color' 'Diameter' 'Volume' 'Tag'};

for k=1:maxcolor                      % For every fluorescent channel inspected
    cd(box(k).name);                  % Enter in the folder   
    agglofolder=dir;                    % Store a list of all the images stored 
    [ agglofolder ] = removepoints( agglofolder );   % The same as above. Remove dummy folders
    numphotos=size(agglofolder,1);                         % Store the number of images
    
    for i=1:numphotos                                        % For every image detected
        cd(agglofolder(i).name)                           % Enter in the folder
        files=dir('*.csv');                                        % Make a list of the *.csv files
        files(([files.bytes]==min([files.bytes])))=[];  % Remove  dummy file (only if using data imported from IMARIS)
               
        copymatrix1 = readtable(files(1).name,'HeaderLines',4);     % Read data from the first file (ellipsoid Main axis C )
        nrows=size(copymatrix1,1);                                                     % Store how many cells are in the image
        newpicture=array2table(zeros(nrows,11));
        newpicture.Properties.VariableNames = {'PosX' 'PosY' 'PosZ' 'AxisX' 'AxisY' 'AxisZ' 'Length' 'Color' 'Diameter' 'Volume' 'Tag'};
        newpicture(1:nrows,4:6)=copymatrix1(1:nrows,1:3);           
        
        copymatrix2 = readtable(files(4).name,'HeaderLines',4);      % Read data from total length
        newpicture(1:nrows,7)=array2table(2*table2array(copymatrix2(1:nrows,1)));

        copymatrix3 = readtable(files(5).name,'HeaderLines',4);      % Read data from spatial position
        newpicture(1:nrows,1:3)=copymatrix3(1:nrows,1:3);
      
        newpicture.Color(:)=k;                                       % Add a color tag (use of integers of increasing value)
        
        copymatrix4 = readtable(files(6).name,'HeaderLines',4);      % Read Volume
        newpicture(1:nrows,10)=copymatrix4(1:nrows,1);

        copymatrix5 = readtable(files(2).name,'HeaderLines',4);     % Read both Diameter    
        copymatrix6 = readtable(files(3).name,'HeaderLines',4);

        newpicture(1:nrows,9)=array2table(2*(sqrt(table2array(copymatrix5(1:nrows,1)).*table2array(copymatrix6(1:nrows,1))))); % Apply a geometric mean to compute the average diameter of the cell
        
        newpicture.Tag(:)=i;  % Add the image ID label for identification purposes    

        data_set=[data_set; newpicture];      % Concatenate read data to the data_set table
        
        cd ..       % get out of folder
        
    end
    
    cd ..  % get out of folder

end

clear copymatrix1 copymatrix2 copymatrix3 copymatrix4 copymatrix5 copymatrix6   % remove variables from memory

%%%% ELIMINAR RUIDO EXPERIMENTAL IMARIS 

data_set(1,:)=[];     % remove dummy row 

data_set(data_set.Diameter<0.3,:)=[];    % Remove potential IMARIS errors when thresholding: detected bodies with diameter or length smaller than 0.3 micron
data_set(data_set.Length<0.3,:)=[]; 
[ data_set ] = clusters4(data_set);  % REPLACE PARTICLE LABELS (INITIAL: PICTURE LABEL, END: AGGREGATE LABEL) AGGREGATES IN THE DATA_SET  
T=tabulate(data_set.Tag);       % Create a table with absolute and relative frequencies of repetitions (made for counting aggregates)
singletes=T(T(:,2)==1,1);            % Find singlet cells

for i=1:size(singletes,1)
    data_set([data_set.Tag]==singletes(i),:)=[];       % Remove singlets from data set (we are only interested on analyzing aggregates)
end

data_set=sortrows(data_set,11); % Sort dataset by aggregate tag

T=tabulate(data_set.Tag);       % Recompute T table
T(T(:,2)==0,:)=[];

agglotag=1;                       % Renumbering of aggregate labels with a increasing serie of integer numbers (1,2,3...)
indexini=1;
indexend=1;

for i=1:size(T,1)
   indexend=indexini+T(i,2)-1;
   data_set.Tag(indexini:indexend)=agglotag;
   indexini=indexend+1;
   agglotag=agglotag+1;
end

T=tabulate(data_set.Tag); 
data_set_raw=data_set;

% Compute Variability parameters

% Lacunarity

% Estimate the largest size of the cube to apply the algorithm

largest_bacnum=T(T(:,2)==max(T(:,2)),1); % Find the aggregate with the largest number of cells
lx_max=0;
ly_max=0;
lz_max=0;
center_image=[1000, 1000, 1000]; % Virtual center of the computation cube 
dbac=mean(data_set_raw.Diameter);

for i=1:numel(largest_bacnum)                                                                               % For every aggregate found
    X=data_set_raw{data_set_raw.Tag==largest_bacnum(i),1:3}+1000;             % shift all coordinates from negative values (if any)
    lbac=max(data_set_raw.Length(data_set_raw.Tag==largest_bacnum(i)));
    maxx=max(X(:,1))+0.5*lbac;
    minx=min(X(:,1))-0.5*lbac;
    maxy=max(X(:,2))+0.5*lbac;
    miny=min(X(:,2))-0.5*lbac;
    maxz=max(X(:,3))+0.5*lbac;
    minz=min(X(:,3))-0.5*lbac;
    
    lx_max=max([lx_max maxx-minx]);           % length required to put inside the aggregate (in each dimension)   
    ly_max=max([ly_max maxy-miny]);
    lz_max=max([lz_max maxz-minz]);
    
end

max_cubelengthxyz=[lx_max ly_max,lz_max];   % Array with the largest lengths in XYZ direction
clear lx_max ly_max lz_max

lbox=max(max_cubelengthxyz);
lboxx=1.05*lbox;
lboxy=1.05*lbox;
lboxz=1.05*lbox;

% Lacunarity c�lculation parameters

nx = 45; % Spatial resolution of the method 
step=1;  % Number of units that the counting box advances 
rpoints=[1 2 4:4:round(0.5*nx)]; % Size of the different boxes that are going to be used to compute Lacunarity 
indices=(1:numel(T(:,1)))';

[ lacunarity_r ] = calculate_lacunarity_v3( max_cubelengthxyz, center_image, data_set_raw,T,step,nx,lbac,dbac, rpoints ); % Obtain lacunarity
lacunarity_r = [T(:,2) lacunarity_r]; % Add a column with the number of bacteria in lacunarity measurements

lacunarity_stat=cell2table({0,0,0,0});                                                                      % Tabulate results
lacunarity_stat.Properties.VariableNames={'Tag_aggregate','NP','r','LAC'};
for i=1:size(lacunarity_r,1)
    for j=2:size(lacunarity_r,2)
        lacunarity_stat=[lacunarity_stat ;{indices(i),lacunarity_r(i,1),rpoints(j-1),lacunarity_r(i,j)}];
    end
end
lacunarity_stat(1,:)=[];   % Remove dummy first row

%%% Plot lacunarity
boxes=unique(lacunarity_stat.r);
for i=1:numel(boxes)
   chosen= lacunarity_stat.LAC(lacunarity_stat.r==boxes(i));
   lacuns(i)=mean(chosen);
end
plot(log10(boxes),log10(lacuns),'-xb')

% Compute geoemtric and composition parameters
[micro_aggregates,contacts,connectdist,CSD,CCD,agglo_color_data,agglo_color_tab ] = dataset_agglo_stat_v9( data_set_raw,T,nbac,dimcolor);  

% Add the name of your strain to a column called "Strain" into the exported data table    
micro_aggregates.Strain=repmat(string({strain_name}),size(micro_aggregates,1),1);
agglo_color_tab.Strain=repmat(string({strain_name}),size(agglo_color_tab,1),1);

micro_aggregates_table=table(0,0,0,0,0,0,string('KK'),'VariableNames',{'EVD','RG','NP','TREE','ECCEN','BONDSVOL','Strain'});
agglo_color_table=table(0,0,0,0,0,0,0,0,0,0,0,0,string('KK'),'VariableNames',{'NP','NCELLG','NCELLR','GGBONDPROB','GRBONDPROB','RRBONDPROB','DISTGG','DISTGR','DISTRR','DISTALL','ENTROPY_COLOR','ENTROPY_BOND','Strain'});

micro_aggregates_table=[micro_aggregates_table;micro_aggregates];
agglo_color_table=[agglo_color_table;agglo_color_tab];

% delete dummy first member
micro_aggregates_table(1,:)=[];
agglo_color_table(1,:)=[];

% Remove further computation errors 
chosen=find( micro_aggregates_table.BONDSVOL==0 | (~logical(agglo_color_table.RRBONDPROB+agglo_color_table.GRBONDPROB+agglo_color_table.GGBONDPROB)));
micro_aggregates_table(chosen,:)=[];
agglo_color_table(chosen,:)=[];

%%% Plots
% CSD
[N1,~] = histcounts(micro_aggregates_table.NP(strcmp(micro_aggregates_table.Strain,strain_name)),'BinWidth',1,'normalization','probability','BinMethod','integers');
N1=[0 N1];

xaxis=1:13;
plot(xaxis,N1,'-xr')
xlim([0 21])
ylim([0 0.7])
xlabel('Number of bacteria in aggregate')
ylabel('frequency')

% Fractal exponent
dbac_exp=mean(data_set_raw.Diameter);
mdl1=fitlm(log(micro_aggregates_table.RG(strcmp(agglo_color_table.Strain,strain_name))/dbac_exp),log(micro_aggregates_table.NP(strcmp(agglo_color_table.Strain,'371'))));
coeffs1= mdl1.Coefficients.Estimate;
Ef=coeffs1(2);

%%% Create the table to generate Andrew's plot from          
part_a=micro_aggregates_table(:,[1 2 3 4 5 6]);
part_b=agglo_color_table(:,[4 5 6 7 8 9 10 11 12]);
andrews_table_all=[part_a part_b];
labels=repmat({strain_name},size(andrews_table_all,1),1);
figure(1),andrewsplot(table2array(andrews_table_all),'group',labels,'quantile',0.25)

%%% PCA plot %%%
variables=[{'EVD'} ,{'RG'} ,{'NP'} ,{'TREE'} ,{'ECCEN'} ,{'BONDSVOL'} ,{'GGBONDPROB'} ,{'GRBONDPROB'} ,{'RRBONDPROB'} ,{'DISTGG'} ,{'DISTGR'} ,{'DISTRR'} ,{'DISTALL'} ,{'ENTROPY_COLOR'} ,{'ENTROPY_BOND'}];

Z=table2array(andrews_table_all);
[coeff,score,latent,tsquared,explained,mu]=pca(Z,'centered','off');
obslabels=repmat({strain_name},size(andrews_table_all,1),1);

h3=biplot(coeff(:,1:3),'Scores',score(:,1:3),'VarLabels',variables,'Color','m','ObsLabels',obslabels);
for k=46:46+size(andrews_table_all,1)
    h3(k).Color='b';
end

%%%% PLOT 2D-HISTOGRAM OF C1-C2 COMPONENT
sc=score(:,1:2);
[N1,Xedges, Yedges]=histcounts2(sc(:,1),sc(:,2),0:10,-5:5);
N1=N1/size(sc,1);                                                   % Normalice histcount matrix to see probability of appearance
figure(1), heatmap(N1*100,'ColorLimits',[0 1])

