
%  FCfloc_Analyzer_v1- Flow Cytometry analysing script to characterize microbial floc variability                   
%  
%  GENERAL DESCRIPTION
%  --------------------
%  This script process FSCA - SSCA data obtained from Flow Cytometry (FC) analysis gathered from an aggregated sample
%  stored as *.CSV files. The script measure the dispersion of the obtained data points and compute a set of metrics that 
%  characterize the morphological variability of the flocs present in the sample. This quantification is given as a set of normalized scores
%  for each target metric that are plot together into a radar chart, obtaining a multidimensional profile where samples can be compared graphically 
%  
%
%   INPUT:
%
%   Flow Cytometry files containing FSCA-SSCA data of aggregated samples
%       
%   OUTPUT
% 
%   A table containing a set of metrics quantifying the aggregate variability of the provided FC data 
%
%
%  DATA PROCESSING DESCRIPTION AND WARNINGS
%  ---------------------
%  The program is designed to automatically load all *.csv files present in the script folder containing FSCA-SSCA lectures.   
%  Files have to be named first withe sample name followed by a low hyphen: Strain name_User ID (i.e. KT2440_TOM29052020)     
%  The program will automatically pick the samples using the default ordering criterium used by windows explorer,          
%  and store all the rows in a table having 4 columns:
%  1- FSCA: Contain FSCA values (float)
%  2- SSCA: Contain SSCA values (float)
%  3- Strain: Contain the "Strain name" included in the filename (String).
%  4- Repetition: If more than 1 replica (files) are present, the program adds a numberic label in ascending order: 1,2,3 ...   (float)    
%  
%  
%  To be properly processed, Flow Cytometry data have to be formatted as follows :
%
%    - Cytometer files must be converted from their native format to *CSV files 
%    - Every file is considered a separated sample 
%    - CSV Files have to be named first withe sample name followed by a low hyphen (e.g. Strain name_User ID) 
%    - CSV Files must be placed within the same folder as this script
%    - CSV files must be structured following the standard :
%         * Rows =>  
%                First row ==> Field headers  
%                Rest of the rows ==> Lectures
%         * Columns => Fields
%    - CSV files must contains two fields given in this order:
%        * First column ==> 'FSCA'
%        * Second column ==> 'SSCA'
%
%
%
% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear

metrics=table("dummy",0,0,0,0,0,0,0,'VariableNames',{'Strain','Md','Sp','Cv','Or','Rd','Ad','Repetition'});   % Create the table where the processed output will be included

basepath='F:\Maletin de trabajo\Bacterial Origami\Coronavirus crisis work 12_05_20\Origami paper\code\Cytometer';   % Add here the path where this script and your files are stored
cd(basepath);      % Change to target path
addpath(genpath(basepath))  % Add basepath to matlab work environment
addpath('F:\Maletin de trabajo\Bacterial Origami\Coronavirus crisis work 12_05_20\Origami paper\code\Cytometer')  % Add basepath to matlab work environment 


data_set_all=table(0,0,{'Nil'},0);                                                                                  % Create the table where FC data points of all samples will be stored to be used in future calculations 
data_set_all.Properties.VariableNames = {'FSCA' 'SSCA' 'Strain' 'repetition'};     % Include headers

files=dir('*.csv');            % Index all *.csv files to process

% For every *.csv file found ...
for i=1:numel(files) 
    p=files(i).name;
    lengthname=find(p=='_')-1;
    name_strain=p(1:lengthname);                                    % Store the name of the strain / sample (all characters before the low bar, see instructions above)
    aux=readtable(files(i).name,'HeaderLines',1);            % load file data into aux table
    aux.Properties.VariableNames = {'FSCA' 'SSCA'};   % include proper header to read data
    strain_rep    = cell(size(aux,1),2);
    strain_rep(:,1) =cellstr(name_strain);
    
    %%% Check if strain has been already stored. If so, count how many repetitions and add repetition tag as required  
    mask=strcmp(data_set_all.Strain,name_strain);
    if any(mask)
       repvalues_chosen=max(unique(data_set_all.repetition(mask)));
       rep=repvalues_chosen+1;
       strain_rep(:,2) ={rep};
    else
       strain_rep(:,2) ={1}; 
    end
    strain_rep=cell2table(strain_rep,'VariableNames',{'Strain' 'repetition'}); % Concatenate data to auxiliar variable including strain/sample name and biol�gical repetition number
    aux=[aux strain_rep];
    data_set_all=[data_set_all ;aux]; % Store harvested data into the global data table
end
data_set_all(1,:)=[];   % Delete first row (dummy row)

strains=unique(data_set_all.Strain);  % Detect the number of strains stored in global data table
target_sampleset=1:numel(strains);  % Numbering vector

%%% For each sample /strain 

for i=1:numel(strains)
    chosen_sample=strains(i);                                                               % Choose the strain label
    elem_mask=strcmp(data_set_all.Strain,chosen_sample);            % Obtain the boolean filter mask in the global table
    nsamples=numel(unique(data_set_all.repetition(elem_mask)));   % Obtain the number of repetitions
    agg_strain=data_set_all(elem_mask,:);                                           % Filter strain elems from global table
    [D,E,G,K,Ls,Lt] = metrics_v7(agg_strain,nsamples);                     % Evaluate metrics
    auxx=cell(size(D,2),8);                                                                       % Store data in auxiliary table
    auxx(:,1) =cellstr(chosen_sample);
    auxx(:,2)=num2cell(D);
    auxx(:,3)=num2cell(E);
    auxx(:,4)=num2cell(G);
    auxx(:,5)=num2cell(K);
    auxx(:,6)=num2cell(Ls);
    auxx(:,7)=num2cell(Lt);    
    auxx(:,8)=num2cell(1:size(D,2));
    metrics=[metrics; cell2table(auxx,'VariableNames',{'Strain','Md','Sp','Cv','Or','Rd','Ad','Repetition'})];   % Attach obtained values to "metrics" table
end
metrics(1,:)=[];    % Delete first dummy row 


omedian = @(x) median(x,'omitnan');                                               %% Compute the median of each metric and store it in a new table 
medianByStrain = varfun(omedian,metrics,'GroupingVariables','Strain',...
                      'InputVariables',{'Md','Sp','Cv','Or','Rd','Ad'});
medianByStrain.Properties.VariableNames(3:8)={'Md','Sp','Cv','Or','Rd','Ad'};

Nstar= 1E4;                                                                                        % Normalization constants        
dstar=sqrt(Nstar);
rhostar=1E2; 

medianByStrain.Md=medianByStrain.Md./Nstar;                              % Normalize variables        
medianByStrain.Sp=medianByStrain.Sp/rhostar;                           
medianByStrain.Cv=medianByStrain.Cv./Nstar;                         
medianByStrain.Or=medianByStrain.Or./Nstar;                         
medianByStrain.Rd=medianByStrain.Rd./dstar;                               
medianByStrain.Ad=medianByStrain.Ad./dstar;                               

%%% PLOT %%%%

chosen_sample_plot=[1,2,3];                                                            % Pick samples to plot    
param=[3 4 5 6 7 8];                                                                           % Pick parameters to plot
legend_samples=medianByStrain.Strain(chosen_sample_plot);   % Add legend content


figure(1), radarplot_v3(table2array(medianByStrain(chosen_sample_plot,param)),{'Md','Sp','Cv','Or','Rd','Ad'})   % Plot radar chart
legend(legend_samples)


%%% Compute T-student test with 95% confidence

oMean = @(x) mean(x,'omitnan');                                          %% Compute the mean 
MeanByStrain = varfun(oMean,metrics,'GroupingVariables','Strain',...
                      'InputVariables',{'Md','Sp','Cv','Or','Rd','Ad'});
MeanByStrain.Properties.VariableNames(3:8)={'Md','Sp','Cv','Or','Rd','Ad'};

results_studtest=[];
for i=1:numel(strains)                                                              %% For each strain / sample, compute a T-test for every computed parameter
    name=strains(i);
    chosen=metrics(strcmp(metrics.Strain,name),:);

    mean_samples_Md=MeanByStrain.Md(strcmp(MeanByStrain.Strain,name));
    hMd=ttest(chosen.Md-mean_samples_Md);

    mean_samples_Sp=MeanByStrain.Sp(strcmp(MeanByStrain.Strain,name));
    hSp=ttest(chosen.Sp-mean_samples_Sp);

    mean_samples_Cv=MeanByStrain.Cv(strcmp(MeanByStrain.Strain,name));
    hCv=ttest(chosen.Cv-mean_samples_Cv);

    mean_samples_Or=MeanByStrain.Or(strcmp(MeanByStrain.Strain,name));
    hOr=ttest(chosen.Or-mean_samples_Or);

    results_studtest=[results_studtest; [hMd  hSp hCv hOr]];  %%%% todos los test PASAN, OK
end

if any(any(results_studtest))                                                     %% Print final T-test result
    display('At least a T-student test have failed at 95% confidence interval')
else
    display('All T-student tests have passed at 95% confidence interval')
end







