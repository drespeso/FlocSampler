function [d,E,G,K,Ls,Lt] = metrics_v7(agg_strain,nsamples)

%%% metrics_v7 %%%
% This function takes the FSCA - SSCA values of a certain sample set (may be more than one experimental replica)
% and compute the set of metrics describing the variability within the analyzed sample


% The MIT License (MIT)
% 
% Copyright (c) 2020 David R. Espeso
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% 
%   $Version: 1.0 $  $Date: 2020/08/27 $
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

max_FSCA=1E4;   % Maximum value of FSCA and SSCA 
max_SSCA=1E4;

d=[]; % raw area value
E=[];
G=[];
K=[];
Ls=[];
Lt=[];

for i=1:nsamples
    display(i)
    agg_plasmid_values=agg_strain(agg_strain.repetition == i,:);
    
    % remove zero / negative values
    agg_plasmid_values(agg_plasmid_values.FSCA<=0,:)=[];
    agg_plasmid_values(agg_plasmid_values.SSCA<=0,:)=[];

    % Compute raw occupied area. Use 2D histogram with bin size = 1  
    
    [count_agg_plasmid]=histcounts2(agg_plasmid_values.FSCA,agg_plasmid_values.SSCA,[1E4,1E4],'Normalization','count','XBinLimits',[0,max_FSCA],'YBinLimits',[0,max_SSCA]);
    
    % Find connected regions in binned chart
    CC_agg = bwconncomp(count_agg_plasmid);
    L_agg = labelmatrix(CC_agg);
    stats_agg = regionprops('table',L_agg,'Area','MajorAxisLength','MinorAxisLength');
    stats_agg.tag=(1:1:size(stats_agg,1))';
    stats_agg=sortrows(stats_agg,-1);
       
    %%% Md calculation (en n�mero de casillas discretizadas) 
    delta=sum(stats_agg.Area);   % Md
    
    %%% Cv calculation
    gamma=stats_agg.Area(1); 
    
    %%% drop the upper 1% percentile of the distribution (outlier)
    distrib_ordered_agg=sortrows(agg_plasmid_values,-1);
    nelems_drop=round(size(distrib_ordered_agg,1)*(1-0.99));
    distrib_ordered_agg(1:nelems_drop,:)=[];
           
    % Sp calculation
    eta=sum(sum(count_agg_plasmid))/sum(sum(count_agg_plasmid~=0));

    % Or calculation  
    kappa=sum(stats_agg.Area==1); 
        
    %%% Fit 2 degree polynomial as "population trend", and perform a change of coordinate system   
    mdl_agg = fit(table2array(distrib_ordered_agg(:,1)),table2array(distrib_ordered_agg(:,2)),'poly2');
    coeffs=coeffvalues(mdl_agg);
    apol=coeffs(1);
    bpol=coeffs(2);
    cpol=coeffs(3);

    %%% CHANGE OF COORDINATES (FSCA,SSCA)  ==> (S,T), S= ORTHOGONAL DISTANCE TO mdl_agg polynomial ; T = arc length in polynomial to reach S    
    
    %1 => Find shortest distance from (FSCA,SSCA) points to mdl_agg polynomial, by finding the X position which provides the shortest distance           
    eval_poly_coeffs = @(x,y)[4*apol*ones(size(x,1),1),6*apol.*bpol*ones(size(x,1),1),2*(1+bpol.^2+2*apol.*(cpol-y)),2*bpol.*(cpol-y)-2*x];
    poly_coeffs=eval_poly_coeffs(table2array(distrib_ordered_agg(:,1)),table2array(distrib_ordered_agg(:,2)));
    xpositions=zeros(size(poly_coeffs,1),1);
    xps=table2array(distrib_ordered_agg(:,1));
    yps=table2array(distrib_ordered_agg(:,2));    
    
    for k=1:size(poly_coeffs,1)
        raices=roots(poly_coeffs(k,:));
        raices(imag(raices)~=0)=[];
        if numel(raices)>1
            xp=xps(k);
            yp=yps(k);
            eval_D2 = @(x) apol*x.^4 +2*apol.*bpol*x.^3+(1+bpol^2+2*apol*(cpol-yp)).*x.^2+(2*bpol*(cpol-yp)-2*xp).*x+(xp^2+(cpol-yp)^2);
            D2=eval_D2(raices);
            xpositions(k)=raices(D2==min(D2));           
        else
            xpositions(k)=raices;   
        end
    end
    %2 => Evaluate s coordinates
    distrib_ordered_agg_rot=array2table(zeros(numel(xpositions),2),'VariableNames',{'t','s'});
    
    distrib_ordered_agg_rot.s=sign(xpositions-table2array(distrib_ordered_agg(:,1))).*sqrt((xpositions-table2array(distrib_ordered_agg(:,1))).^2+(apol*xpositions.^2+bpol*xpositions+cpol-table2array(distrib_ordered_agg(:,2))).^2);
    
    %3 => Evaluate t by first finding the minumum FSCA value and computing its xpos value
    xposition_min=xpositions(table2array(distrib_ordered_agg(:,1))==min(table2array(distrib_ordered_agg(:,1))));
    if numel(xposition_min)>1
       xposition_min=min(abs(xposition_min)); 
    end
    eval_t = @(x) x+4*apol^2*x.^3/3+4*apol*bpol*x.^2/2+bpol^2*x; %%% define integrated polynomial to evaluate t arclength
    distrib_ordered_agg_rot.t=eval_t(xpositions)-ones(numel(xpositions),1)*eval_t(xposition_min);
    
    %4 => % Rd and Ad calculation    
    
    lambda_s=std(distrib_ordered_agg_rot.s);     
    lambda_t=std(distrib_ordered_agg_rot.t);       

    % Merge results
    d=[d delta];
    E=[E eta];
    G=[G gamma];
    K=[K kappa];
    Ls=[Ls lambda_s];          
    Lt=[Lt lambda_t];          
end


end